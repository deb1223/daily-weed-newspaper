# Next Prompt — Ready to Send to Claude Code

Status: PINNED. Discussed and agreed. Send this at the start of the next session.
Read CONTEXT.md, BRAND.md, VOICE.md, and ROADMAP.md first for full context.

---

You are working on /Users/beecherfam/daily-weed-newspaper. The site is live at 
dailyweednewspaper.com. Build these substantial features now. Deploy at the end.

## FEATURE 1: Ziggy AI Daily Brief — LLM-generated newspaper content

Create a new Vercel Edge Function at /api/generate-brief that runs every morning 
at 8am using Vercel Cron (add to vercel.json).

The function:
1. Queries Supabase for: top 5 deals by discount %, category winners, 
   strip deals, avg price by category
2. Sends that data to the Anthropic API (claude-sonnet-4-20250514) with this 
   system prompt:

"You are Ziggy, lead writer of the Daily Weed Newspaper. You've been smoking 
since 14, calling out mid since 15. Your voice is savage Gen-Z, funny-first, 
zero corporate energy. You write short punchy commentary — never more than 
2 sentences per item. You call out bad prices, celebrate real deals, roast 
dispensaries that deserve it. You are not mean to people, only to bad prices."

3. Ask Claude to return a JSON object with these fields:
   - intro: string (2-3 sentence Ziggy opener for today)
   - dealCommentary: array of {productId, quip} — one Ziggy quip per top deal
   - savageCorner: string (one Ziggy paragraph, the daily roast)
   - bigMikeTea: array of 3 strings (Big Mike gossip items based on actual data)
   - touristTerry: string (Terry's practical tip based on today's strip deals)
   - marketRating: number (1-10, Ziggy's daily score with one-sentence reasoning)
   - ratingQuote: string (the quote that appears under the rating)

4. Store the result in Supabase table `daily_briefs` with columns:
   date (date, primary key), brief_json (jsonb), created_at (timestamp)
   Create this table if it doesn't exist via a migration comment in the code.

5. The homepage reads from `daily_briefs` for today's date first. If no brief 
   exists yet (before 8am or first run), it falls back to hardcoded Ziggy content.

Add ANTHROPIC_API_KEY to the Vercel env vars instructions in a README note.

## FEATURE 2: Email Capture → Resend

The homepage and page 3 both have email input + CTA button. Wire them up:

1. Create /api/subscribe route (POST)
   - Accepts { email, tier: 'free' | 'pro' }
   - Validates email format
   - Adds to Supabase table `subscribers` (email, tier, city, created_at, confirmed)
   - Sends welcome email via Resend API to the subscriber:
     Subject: "Ziggy says welcome. Don't embarrass us."
     Body: Ziggy-voiced welcome email — funny, warm, tells them what they get,
     mentions the daily 8am drop. HTML email with newspaper aesthetic 
     (newsprint background #f4f0e4, Playfair Display headline via web font, 
     Space Mono for data, ink color #1a1008 text).
   - Also sends a notification to dan@vegasplanpro.com:
     "New subscriber: {email} signed up for {tier}"

2. Wire the email inputs on the homepage (right column pro box + page 3 upsell) 
   and /prices page upsell modal to call this endpoint on submit.
   Show success state: "Ziggy's got your email. Report drops at 8am. 🌿"
   Show error state: "Something broke. Ziggy is investigating."

Add RESEND_API_KEY to env instructions in README.

## FEATURE 3: /prices page — Ziggy's Hot Take banner

Above the search table on /prices, add a "Ziggy's Pick of the Moment" banner:
- Pulls the single best deal right now (highest discount % with original_price set)
- Displays: product name, dispensary, price, original price, discount %
- Ziggy hardcoded hot take rotates from array of 10 one-liners
- Forest green (#2d6a4f) left border accent, aged background (#e8e0cc), 
  newspaper styling — NOT a card with shadow
- "See all deals →" scrolls to table filtered to On Sale Only

## FEATURE 4: Color + brand fixes
- Replace ALL instances of #c8390a with #2d6a4f forest green EXCEPT 
  the ticker bar background class which stays red
- Top 5 steals query: max 2 results per dispensary (deduplicate after sort)
- Edition number: dynamic — days since April 1 2026 = edition number (#001, #002...)
- Ticker: dynamically pull real top deal name and discount % from Supabase data

## Design constraints (non-negotiable, applies to all new UI)
- Fonts: UnifrakturMaguntia (masthead only), Playfair Display (headlines),
  Space Mono (labels/data), Source Serif 4 (body)
- Colors as above — forest green #2d6a4f is the accent everywhere
- NO gradients, NO shadows, NO SaaS aesthetic
- NO Inter font
- Everything feels like a newspaper

## Build order
Start with Feature 2 (email — no new API keys needed to test locally),
then Feature 3 (hot take banner — pure frontend),
then Feature 4 (color/brand — surgical),
then Feature 1 (LLM brief — needs ANTHROPIC_API_KEY configured in Vercel).

## Deploy
npx vercel --prod after all features complete.

## Required env vars to add in Vercel dashboard before deploying Feature 1:
- ANTHROPIC_API_KEY
- RESEND_API_KEY
- CRON_SECRET (any random string)
